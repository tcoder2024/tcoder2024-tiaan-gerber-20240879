using System;
using System.Drawing;
using System.Windows.Forms;

namespace GreetingApp
{
    public partial class Form1 : Form
    {
        private TextBox txtName;
        private Button btnGreet;
        private Label lblGreeting;
        private Label lblInstruction;

        public Form1()
        {
            // Form settings
            this.Text = "Greeting Application";
            this.Size = new Size(400, 250);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.White;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            // Instruction label
            lblInstruction = new Label();
            lblInstruction.Text = "Enter your name:";
            lblInstruction.Font = new Font("Segoe UI", 11, FontStyle.Bold);
            lblInstruction.Location = new Point(30, 30);
            lblInstruction.Size = new Size(150, 25);

            // Text box for name input
            txtName = new TextBox();
            txtName.Location = new Point(30, 60);
            txtName.Size = new Size(200, 27);
            txtName.Font = new Font("Segoe UI", 11);

            // Greeting button
            btnGreet = new Button();
            btnGreet.Text = "Greeting";
            btnGreet.Location = new Point(30, 100);
            btnGreet.Size = new Size(100, 35);
            btnGreet.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            btnGreet.BackColor = Color.FromArgb(0, 120, 215);
            btnGreet.ForeColor = Color.White;
            btnGreet.FlatStyle = FlatStyle.Flat;
            btnGreet.Click += BtnGreet_Click;

            // Greeting label (to show result)
            lblGreeting = new Label();
            lblGreeting.Text = "";
            lblGreeting.Font = new Font("Segoe UI", 12, FontStyle.Bold);
            lblGreeting.ForeColor = Color.FromArgb(0, 120, 215);
            lblGreeting.Location = new Point(30, 150);
            lblGreeting.Size = new Size(320, 40);

            // Add controls to form
            this.Controls.Add(lblInstruction);
            this.Controls.Add(txtName);
            this.Controls.Add(btnGreet);
            this.Controls.Add(lblGreeting);
        }

        private void BtnGreet_Click(object? sender, EventArgs e)
        {
            string name = txtName.Text.Trim();

            if (string.IsNullOrWhiteSpace(name))
            {
                lblGreeting.Text = "Please enter your name!";
                lblGreeting.ForeColor = Color.Red;
            }
            else
            {
                lblGreeting.Text = $"Hello {name}!";
                lblGreeting.ForeColor = Color.FromArgb(0, 120, 215);
            }
        }

        private void InitializeComponent()
        {

        }
    }
}