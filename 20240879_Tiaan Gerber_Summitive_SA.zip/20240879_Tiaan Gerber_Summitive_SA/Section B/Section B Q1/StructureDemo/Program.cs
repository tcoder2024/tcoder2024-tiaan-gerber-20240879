﻿// Tiaan Gerber_20240879
// Section B question 1: Structure of a C# Program


using System;

namespace StructureDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            // Step 1: Welcome message
            Console.WriteLine("Welcome to the Structure of a C# Program Demo!");

            // Step 2: Ask for name
            Console.Write("Enter your name: ");
            string name = Console.ReadLine();

            // Step 3: Greet user
            Console.WriteLine($"Hello {name}!");
            Console.WriteLine();

            // Step 4: Explain program structure
            Console.WriteLine("Program Structure Demonstrated:");
            Console.WriteLine("1. using System : imports functionality");
            Console.WriteLine("2. namespace : organizes code");
            Console.WriteLine("3. class Program : container for code");
            Console.WriteLine("4. Main() : entry point of program");
            Console.WriteLine("5. Comments : explain logic and documentation");
            Console.WriteLine();

            // Step 5: Completion message
            Console.WriteLine("Program executed successfully!");

            // Keep console window open
            Console.ReadKey();
        }
    }
}