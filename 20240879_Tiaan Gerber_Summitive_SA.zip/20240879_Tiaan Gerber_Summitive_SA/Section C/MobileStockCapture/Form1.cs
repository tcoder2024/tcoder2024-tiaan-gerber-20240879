using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace MobileStockCapture
{
    public partial class Form1 : Form
    {
        private List<MobileStock> stockList;
        private ListBox lstDisplay;

        private Label lblOutput;
        private Label lblCode;
        private Label lblMake;
        private Label lblQuantity;

        private TextBox txtCode;
        private TextBox txtMake;
        private TextBox txtQuantity;

        private Button btnFind;
        private Button btnAdd;
        private Button btnDelete;

        public Form1()
        {
            InitializeComponent();
            SetupForm();
            CreateControls();
            stockList = new List<MobileStock>();
        }

        private void SetupForm()
        {
            this.Text = "Mobile Stock Capture";
            this.Size = new Size(450, 500);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
        }

        private void CreateControls()
        {
            // lblOutput (top label)
            lblOutput = new Label();
            lblOutput.Text = "lblOutput";
            lblOutput.Location = new Point(30, 20);
            lblOutput.Size = new Size(100, 25);
            lblOutput.Font = new Font("Segoe UI", 10, FontStyle.Bold);

            // txtCode and lblCode (row 1)
            lblCode = new Label();
            lblCode.Text = "Code";
            lblCode.Location = new Point(30, 60);
            lblCode.Size = new Size(80, 25);

            txtCode = new TextBox();
            txtCode.Location = new Point(120, 58);
            txtCode.Size = new Size(200, 27);

            // txtMake and lblMake (row 2)
            lblMake = new Label();
            lblMake.Text = "Make";
            lblMake.Location = new Point(30, 100);
            lblMake.Size = new Size(80, 25);

            txtMake = new TextBox();
            txtMake.Location = new Point(120, 98);
            txtMake.Size = new Size(200, 27);

            // txtQuantity and lblQuantity (row 3)
            lblQuantity = new Label();
            lblQuantity.Text = "Quantity";
            lblQuantity.Location = new Point(30, 140);
            lblQuantity.Size = new Size(80, 25);

            txtQuantity = new TextBox();
            txtQuantity.Location = new Point(120, 138);
            txtQuantity.Size = new Size(200, 27);

            // Buttons row
            btnFind = new Button();
            btnFind.Text = "Find";
            btnFind.Location = new Point(30, 190);
            btnFind.Size = new Size(90, 35);
            btnFind.Click += BtnFind_Click;

            btnAdd = new Button();
            btnAdd.Text = "Add";
            btnAdd.Location = new Point(130, 190);
            btnAdd.Size = new Size(90, 35);
            btnAdd.Click += BtnAdd_Click;

            btnDelete = new Button();
            btnDelete.Text = "Delete";
            btnDelete.Location = new Point(230, 190);
            btnDelete.Size = new Size(90, 35);
            btnDelete.Click += BtnDelete_Click;

            // ListBox to display stock items (as shown in diagram)
            lstDisplay = new ListBox();
            lstDisplay.Location = new Point(30, 250);
            lstDisplay.Size = new Size(370, 180);
            lstDisplay.Font = new Font("Consolas", 10);

            // Add all controls
            this.Controls.Add(lblOutput);
            this.Controls.Add(lblCode);
            this.Controls.Add(txtCode);
            this.Controls.Add(lblMake);
            this.Controls.Add(txtMake);
            this.Controls.Add(lblQuantity);
            this.Controls.Add(txtQuantity);
            this.Controls.Add(btnFind);
            this.Controls.Add(btnAdd);
            this.Controls.Add(btnDelete);
            this.Controls.Add(lstDisplay);
        }

        private void BtnAdd_Click(object? sender, EventArgs e)
        {
            string code = txtCode.Text.Trim();
            string make = txtMake.Text.Trim();
            string quantityText = txtQuantity.Text.Trim();

            // Validation
            if (string.IsNullOrWhiteSpace(code))
            {
                lblOutput.Text = "Please enter code";
                return;
            }
            if (string.IsNullOrWhiteSpace(make))
            {
                lblOutput.Text = "Please enter make";
                return;
            }
            if (!int.TryParse(quantityText, out int quantity) || quantity < 0)
            {
                lblOutput.Text = "Quantity must be a positive number";
                return;
            }

            // Check if code already exists
            foreach (var item in stockList)
            {
                if (item.Code.ToLower() == code.ToLower())
                {
                    lblOutput.Text = "Code already exists";
                    return;
                }
            }

            // Add new stock
            MobileStock stock = new MobileStock
            {
                Code = code,
                Make = make,
                Quantity = quantity
            };
            stockList.Add(stock);
            RefreshDisplay();

            // Clear fields
            txtCode.Clear();
            txtMake.Clear();
            txtQuantity.Clear();
            txtCode.Focus();

            lblOutput.Text = "Stock added successfully";
        }

        private void BtnFind_Click(object? sender, EventArgs e)
        {
            string code = txtCode.Text.Trim();

            if (string.IsNullOrWhiteSpace(code))
            {
                lblOutput.Text = "Please enter code to find";
                return;
            }

            foreach (var item in stockList)
            {
                if (item.Code.ToLower() == code.ToLower())
                {
                    txtMake.Text = item.Make;
                    txtQuantity.Text = item.Quantity.ToString();
                    lblOutput.Text = "Record found";
                    return;
                }
            }

            lblOutput.Text = "Code not found";
            txtMake.Clear();
            txtQuantity.Clear();
        }

        private void BtnDelete_Click(object? sender, EventArgs e)
        {
            string code = txtCode.Text.Trim();

            if (string.IsNullOrWhiteSpace(code))
            {
                lblOutput.Text = "Please enter code to delete";
                return;
            }

            for (int i = 0; i < stockList.Count; i++)
            {
                if (stockList[i].Code.ToLower() == code.ToLower())
                {
                    stockList.RemoveAt(i);
                    RefreshDisplay();
                    txtCode.Clear();
                    txtMake.Clear();
                    txtQuantity.Clear();
                    lblOutput.Text = "Stock deleted successfully";
                    txtCode.Focus();
                    return;
                }
            }

            lblOutput.Text = "Code not found";
        }

        private void RefreshDisplay()
        {
            lstDisplay.Items.Clear();
            foreach (var item in stockList)
            {
                lstDisplay.Items.Add($"Code: {item.Code}, Make: {item.Make}, Qty: {item.Quantity}");
            }
        }
    }

    // Simple class to hold stock data
    public class MobileStock
    {
        public string Code { get; set; } = "";
        public string Make { get; set; } = "";
        public int Quantity { get; set; }
    }
}